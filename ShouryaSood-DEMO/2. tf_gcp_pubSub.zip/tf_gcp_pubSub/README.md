1. HIERARCHY of directories:

    ![Directories](image.png)

2. Best Practises:

    The Pub/Sub resource is encapsulated in a module (modules/pubsub), promoting code reuse and modular design.

    Input variables (variables.tf) are used to parameterize the code, allowing easy configuration for different environments.

    Default values are provided for some variables to enhance flexibility.

    Service account key file path is specified using a variable (credentials_file) for better security and flexibility.

    Output values are defined in both the root and module-level outputs.tf files, making it easy to reference important information after applying the Terraform configuration.

    Resource names are parameterized through variables (pubsub_topic_name), promoting consistency and allowing for easy changes.

    The terraform.tfvars file is used to store environment-specific variable values, making it easy to manage configurations for different environments.



