1. This deployment does the following:

    A. Creates a Deployment with three replicas for high availability.
    B. Defines a Service to expose the NGINX pods to the external world.
    C. The NGINX pods are accessible externally via a LoadBalancer.

2. Deploying the app:

    A. Apply config to kubernetes cluster : 

        minikube start
        kubectl apply -f nginx-deployment.yaml

    B. Apply the deployment & service :

        kubectl apply -f sample-app-deployment.yaml
        kubectl apply -f sample-app-service.yaml

    C. Access the app :

        minikube service sample-app-service

    D. Check ROLLING UPDATES :

        Change yaml file = [image: nginx:1.19]

    E. Apply update :

        kubectl apply -f sample-app-deployment.yaml
